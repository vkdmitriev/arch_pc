#!/bin/bash
tar -cvf ~/backup/backup.tar programm1.sh
